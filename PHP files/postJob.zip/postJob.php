<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "Adbms2023#";
$dbname = "mydb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error)
{
    die("Connection failed: ". $conn->connect_error);
}

$JobTitle = $_POST['jobTitle'];
$PayRate = $_POST['pay_rate'];
$PayPeriod = $_POST['pay_period'];
$JobDomain = $_POST['jobDomain'];
$Deadline = $_POST['deadline'];
$Information = $_POST['information'];
$OrganizationID = $_SESSION['OrgID'];
$RecruiterID = $_SESSION['rid'];

$split_1 = explode("T", $Deadline);
$PayRate = (int)$PayRate;
$OrganizationID = (int)$OrganizationID;
$RecruiterID = (int)$RecruiterID;

$sql3 = "INSERT INTO jobs (JobID, JobTitle, PayRate, PayPeriod, JobDomain, PostingDate, Deadline, Information, OrganizationID, RecruiterID) VALUES (2021, '$JobTitle', $PayRate, '$PayPeriod', '$JobDomain', CURDATE(), '$split_1[0]', '$Information', $OrganizationID, $RecruiterID)";
$result3 = mysqli_query($conn, $sql3) or die("Didn't work...");
// echo $result3;
// header("Location: ../Front-end pages/RProfile.php");
if($result3)
{
    // echo "Success!";
    // header("Location: ../Front-end pages/RProfile.php");
}
else
{
    echo "Failed to Insert...";
}
$conn->close();
?>